namespace MapsterDependencyInjectionTest;

public class CreateProjectRequest : IResourceIdAssociatedRequest
{
    public string Name { get; set; }
    public string ResourceId { get; set; }
}

public class EndpointRequest
{
    public string Name { get; set; }

}
public interface IRequestContext
{
    string GetResourceId();
}

public class RequestContext : IRequestContext
{
    public string GetResourceId() => "resource-hello-id"; // Simulate user/resource context
}