using Mapster;
using MapsterMapper;
namespace MapsterDependencyInjectionTest;

public class MappingConfig : IRegister
{
    public void Register(TypeAdapterConfig config)
    {
        config.NewConfig<EndpointRequest, IResourceIdAssociatedRequest>()
            .Map(dest => dest.ResourceId,
                 src => "resource-hello-id"); // Simulate user/resource context
    }
}