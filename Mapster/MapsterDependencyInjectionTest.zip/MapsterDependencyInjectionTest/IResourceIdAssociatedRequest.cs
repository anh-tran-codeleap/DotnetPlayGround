namespace MapsterDependencyInjectionTest;

public interface IResourceIdAssociatedRequest
{
    string ResourceId { get; set; }
}
